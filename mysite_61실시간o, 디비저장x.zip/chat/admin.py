from django.contrib import admin
from . models import Chat, Chat_cont
# Register your models here.

admin.site.register(Chat)
admin.site.register(Chat_cont)