from django.apps import AppConfig


class AlarmsConfig(AppConfig):
    name = 'alarms'
